package com.moonlight.launcher.modules

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ModuleCatalogTest {
    @Test fun catalogueHasAtLeastSixtyModules() {
        assertTrue("Expected 60+ registered modules", ModuleCatalog.all.size >= 60)
    }

    @Test fun moduleIdsAreUnique() {
        assertEquals(ModuleCatalog.all.size, ModuleCatalog.all.map { it.id }.toSet().size)
    }

    @Test fun unsupportedModulesNeverClaimAnExecutionPath() {
        assertTrue(ModuleCatalog.all.filter { it.status == ModuleStatus.UNSUPPORTED }.all { it.execution == ModuleExecution.NONE })
    }

    @Test fun searchFindsCategoriesAndNames() {
        assertTrue(ModuleCatalog.search("shader").any { it.id == "shader_manager" })
        assertTrue(ModuleCatalog.search("pvp").isNotEmpty())
    }
}
