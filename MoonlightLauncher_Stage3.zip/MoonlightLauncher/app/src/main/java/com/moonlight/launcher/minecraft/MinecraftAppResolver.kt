package com.moonlight.launcher.minecraft

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/** Detects and launches the official Android Bedrock app without accessing its private data. */
object MinecraftAppResolver {
    const val BEDROCK_PACKAGE = "com.mojang.minecraftpe"

    data class Installation(val installed: Boolean, val versionName: String?, val versionCode: Long?)

    @Suppress("DEPRECATION")
    fun detect(context: Context): Installation {
        val packageInfo = try {
            if (Build.VERSION.SDK_INT >= 33) {
                context.packageManager.getPackageInfo(BEDROCK_PACKAGE, PackageManager.PackageInfoFlags.of(0))
            } else {
                context.packageManager.getPackageInfo(BEDROCK_PACKAGE, 0)
            }
        } catch (_: PackageManager.NameNotFoundException) {
            return Installation(false, null, null)
        } catch (_: SecurityException) {
            return Installation(false, null, null)
        }
        val code = if (Build.VERSION.SDK_INT >= 28) packageInfo.longVersionCode else packageInfo.versionCode.toLong()
        return Installation(true, packageInfo.versionName, code)
    }

    fun launch(context: Context): Boolean {
        val intent: Intent = context.packageManager.getLaunchIntentForPackage(BEDROCK_PACKAGE) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }
}
