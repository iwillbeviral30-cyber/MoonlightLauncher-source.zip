package com.moonlight.launcher.client

import android.content.Context
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ── Design tokens (Kuro-inspired dark blue-gray) ──────────────────────────────
private val BgDeep     = Color(0xFF0D0F1A)
private val BgPanel    = Color(0xFF13161F)
private val BgCard     = Color(0xFF1A1D2B)
private val BgCardHov  = Color(0xFF1F2233)
private val BgSidebar  = Color(0xFF0F1119)
private val Accent     = Color(0xFF4C8BF5)  // Kuro blue
private val AccentSoft = Color(0x334C8BF5)
private val TextPrime  = Color(0xFFEAEBF0)
private val TextSub    = Color(0xFF8A8FA8)
private val TextDim    = Color(0xFF555870)
private val Green      = Color(0xFF4ADE80)
private val Yellow     = Color(0xFFFBBF24)
private val Red        = Color(0xFFF87171)
private val Divider    = Color(0xFF1E2130)

@Composable
fun ClientPanel(
    context: Context,
    onClose: () -> Unit
) {
    var selectedCategory by remember { mutableStateOf(ClientCategory.HUD_INFO) }
    var searchQuery by remember { mutableStateOf("") }
    var showSearch by remember { mutableStateOf(false) }
    // Track enabled states reactively
    val enabledMap = remember { mutableStateMapOf<String, Boolean>().also { map ->
        ClientRegistry.all.forEach { m -> map[m.id] = ClientRegistry.isEnabled(context, m.id) }
    }}
    val enabledCount = enabledMap.values.count { it }
    val displayModules = if (searchQuery.isBlank())
        ClientRegistry.forCategory(selectedCategory)
    else
        ClientRegistry.search(searchQuery)

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xAA000000)) // dim backdrop
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) { /* consume taps so they don't fall through */ }
    ) {
        // ── Centered panel ────────────────────────────────────────────────
        Row(
            modifier = Modifier
                .align(Alignment.Center)
                .fillMaxHeight(0.82f)
                .fillMaxWidth(0.92f)
                .clip(RoundedCornerShape(18.dp))
                .background(BgDeep)
        ) {
            // ── Left sidebar ──────────────────────────────────────────────
            Column(
                modifier = Modifier
                    .width(130.dp)
                    .fillMaxHeight()
                    .background(BgSidebar)
                    .padding(vertical = 16.dp),
                horizontalAlignment = Alignment.Start
            ) {
                // Header
                Column(Modifier.padding(horizontal = 14.dp, vertical = 4.dp)) {
                    Text("MOONLIGHT", fontSize = 11.sp, fontWeight = FontWeight.Black,
                        color = Accent, letterSpacing = 1.6.sp)
                    Text("CLIENT", fontSize = 9.sp, color = TextDim, letterSpacing = 1.4.sp)
                }
                Spacer(Modifier.height(4.dp))
                Text("  $enabledCount enabled", fontSize = 9.sp, color = TextDim,
                    modifier = Modifier.padding(horizontal = 14.dp))

                Spacer(Modifier.height(16.dp))

                Text("  MODULES", fontSize = 8.sp, color = TextDim,
                    modifier = Modifier.padding(horizontal = 14.dp),
                    letterSpacing = 1.2.sp)
                Spacer(Modifier.height(6.dp))

                ClientCategory.entries.forEach { cat ->
                    val isSelected = selectedCategory == cat && searchQuery.isBlank()
                    val count = ClientRegistry.forCategory(cat).size
                    SidebarItem(
                        label = cat.label,
                        count = count,
                        selected = isSelected,
                        onClick = { selectedCategory = cat; searchQuery = "" }
                    )
                }

                Spacer(Modifier.weight(1f))

                // Settings button
                SidebarItem("Settings", 0, false, onClick = { /* opens settings below */ },
                    isSettings = true)
                SidebarItem("Keybinds", 0, false, onClick = {}, isSettings = false)
            }

            // ── Right content ─────────────────────────────────────────────
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .background(BgPanel)
            ) {
                // Top bar
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        if (searchQuery.isNotBlank()) {
                            Text("Search Results", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrime)
                            Text("${displayModules.size} modules found", fontSize = 10.sp, color = TextSub)
                        } else {
                            Row {
                                Text(selectedCategory.label, fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold, color = TextPrime,
                                    fontStyle = FontStyle.Italic)
                                Text(" Modules", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = TextPrime)
                            }
                            val active = displayModules.count { enabledMap[it.id] == true }
                            Text("${displayModules.size} modules" +
                                    if (active > 0) " · $active enabled" else "",
                                fontSize = 10.sp, color = TextSub)
                        }
                    }

                    // Search bar
                    if (showSearch) {
                        Box(
                            Modifier
                                .width(160.dp)
                                .height(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(BgCard)
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            BasicTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                textStyle = TextStyle(color = TextPrime, fontSize = 12.sp),
                                singleLine = true,
                                decorationBox = { inner ->
                                    if (searchQuery.isEmpty())
                                        Text("Search modules…", fontSize = 11.sp, color = TextDim)
                                    inner()
                                }
                            )
                        }
                        Spacer(Modifier.width(6.dp))
                    }

                    IconButton(onClick = { showSearch = !showSearch; if (!showSearch) searchQuery = "" },
                        modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.Search, null, tint = if (showSearch) Accent else TextSub,
                            modifier = Modifier.size(18.dp))
                    }
                    Spacer(Modifier.width(4.dp))
                    IconButton(onClick = onClose, modifier = Modifier.size(30.dp)) {
                        Icon(Icons.Default.Close, null, tint = TextSub, modifier = Modifier.size(18.dp))
                    }
                }

                Divider(color = Divider, thickness = 1.dp)

                if (displayModules.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.SearchOff, null, tint = TextDim,
                                modifier = Modifier.size(36.dp))
                            Spacer(Modifier.height(10.dp))
                            Text("No modules found", color = TextSub, fontSize = 13.sp)
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(displayModules, key = { it.id }) { module ->
                            val isEnabled = enabledMap[module.id] == true
                            ModuleCard(
                                module = module,
                                isEnabled = isEnabled,
                                onToggle = { newVal ->
                                    enabledMap[module.id] = newVal
                                    ClientRegistry.setEnabled(context, module.id, newVal)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SidebarItem(
    label: String,
    count: Int,
    selected: Boolean,
    onClick: () -> Unit,
    isSettings: Boolean = false
) {
    val bg = if (selected) AccentSoft else Color.Transparent
    val textColor = if (selected) Accent else TextSub
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topEnd = 8.dp, bottomEnd = 8.dp))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (isSettings) {
            Icon(Icons.Default.Settings, null, tint = textColor, modifier = Modifier.size(13.dp))
            Spacer(Modifier.width(6.dp))
        }
        Text(label, fontSize = 11.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = textColor, modifier = Modifier.weight(1f))
        if (count > 0) {
            Text("$count", fontSize = 9.sp, color = if (selected) Accent else TextDim)
        }
    }
}

@Composable
private fun ModuleCard(
    module: ClientModule,
    isEnabled: Boolean,
    onToggle: (Boolean) -> Unit
) {
    val statusColor = when (module.tier) {
        ModuleTier.OVERLAY_ACTIVE   -> Green
        ModuleTier.APP_ACTIVE       -> Green
        ModuleTier.REQUIRES_ADDON   -> Yellow
        ModuleTier.REQUIRES_RUNTIME -> Red
        ModuleTier.RUNTIME_READY    -> Yellow
    }
    val canToggle = module.tier == ModuleTier.OVERLAY_ACTIVE ||
                    module.tier == ModuleTier.APP_ACTIVE

    val cardBg = if (isEnabled && canToggle) BgCardHov else BgCard

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(cardBg)
            .clickable(enabled = canToggle) { if (canToggle) onToggle(!isEnabled) }
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Enabled indicator dot
        if (isEnabled && canToggle) {
            Box(Modifier.size(6.dp).clip(CircleShape).background(Accent))
            Spacer(Modifier.width(10.dp))
        } else {
            Spacer(Modifier.width(16.dp))
        }

        Column(Modifier.weight(1f)) {
            Text(module.name, fontSize = 13.sp,
                fontWeight = if (isEnabled) FontWeight.SemiBold else FontWeight.Normal,
                color = if (isEnabled && canToggle) TextPrime else Color(0xFFCCCFDE))
            Text(module.description, fontSize = 10.sp, color = TextSub, lineHeight = 13.sp,
                maxLines = 2)
        }

        Spacer(Modifier.width(8.dp))

        // Status badge
        Box(
            Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(statusColor.copy(alpha = 0.12f))
                .padding(horizontal = 6.dp, vertical = 3.dp)
        ) {
            Text(module.statusLabel, fontSize = 8.sp, color = statusColor, fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.width(8.dp))

        if (module.hasSettings) {
            Icon(Icons.Default.ChevronRight, null, tint = TextDim, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
        }

        // Toggle
        Switch(
            checked = isEnabled,
            onCheckedChange = if (canToggle) onToggle else null,
            enabled = canToggle,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Accent,
                uncheckedThumbColor = TextDim,
                uncheckedTrackColor = BgDeep,
                disabledUncheckedThumbColor = TextDim.copy(alpha = 0.4f),
                disabledUncheckedTrackColor = BgDeep.copy(alpha = 0.4f)
            ),
            modifier = Modifier.height(22.dp)
        )
    }
}
