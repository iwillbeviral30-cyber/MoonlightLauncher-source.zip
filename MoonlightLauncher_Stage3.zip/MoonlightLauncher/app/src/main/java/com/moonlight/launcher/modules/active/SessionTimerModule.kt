package com.moonlight.launcher.modules.active

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit

/**
 * Tracks cumulative Moonlight session time across app restarts.
 * Each session start/stop delta is accumulated in SharedPreferences.
 */
object SessionTimerModule {
    private const val PREFS = "moonlight_session"
    private const val KEY_TOTAL_MS = "total_ms"
    private const val KEY_START_MS = "current_start"

    @Volatile private var sessionStart = 0L

    fun onAppStart(context: Context) {
        sessionStart = System.currentTimeMillis()
        prefs(context).edit { putLong(KEY_START_MS, sessionStart) }
    }

    fun onAppStop(context: Context) {
        if (sessionStart == 0L) return
        val elapsed = System.currentTimeMillis() - sessionStart
        val total = prefs(context).getLong(KEY_TOTAL_MS, 0L) + elapsed
        prefs(context).edit {
            putLong(KEY_TOTAL_MS, total)
            remove(KEY_START_MS)
        }
        sessionStart = 0L
    }

    /** Total cumulative ms across all sessions. */
    fun totalMs(context: Context): Long {
        val base = prefs(context).getLong(KEY_TOTAL_MS, 0L)
        val live = if (sessionStart > 0L) System.currentTimeMillis() - sessionStart else 0L
        return base + live
    }

    /** Current session ms only. */
    fun currentSessionMs(): Long = if (sessionStart > 0L) System.currentTimeMillis() - sessionStart else 0L

    fun reset(context: Context) {
        sessionStart = System.currentTimeMillis()
        prefs(context).edit { putLong(KEY_TOTAL_MS, 0L) }
    }

    fun formatDuration(ms: Long): String {
        val totalSeconds = ms / 1000L
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        val s = totalSeconds % 60
        return if (h > 0) "%dh %02dm %02ds".format(h, m, s)
        else "%dm %02ds".format(m, s)
    }

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
