package com.moonlight.launcher.overlay

import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner

/**
 * Minimal LifecycleOwner for the Compose overlay view hosted inside a Service/WindowManager.
 * Required so ComposeView can work outside an Activity context.
 */
class OverlayLifecycleOwner : LifecycleOwner, SavedStateRegistryOwner {
    private val registry = LifecycleRegistry(this)
    private val savedStateController = SavedStateRegistryController.create(this)

    init {
        savedStateController.performAttach()
        savedStateController.performRestore(null)
        registry.currentState = Lifecycle.State.RESUMED
    }

    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateController.savedStateRegistry

    fun destroy() {
        registry.currentState = Lifecycle.State.DESTROYED
    }
}

/**
 * SavedStateRegistryOwner backed by the same controller — kept separate so the
 * Compose view-tree setters receive the right typed owners.
 */
class OverlaySavedStateOwner : SavedStateRegistryOwner {
    private val lifecycleOwner = OverlayLifecycleOwner()
    override val lifecycle: Lifecycle get() = lifecycleOwner.lifecycle
    override val savedStateRegistry: SavedStateRegistry get() = lifecycleOwner.savedStateRegistry
}
