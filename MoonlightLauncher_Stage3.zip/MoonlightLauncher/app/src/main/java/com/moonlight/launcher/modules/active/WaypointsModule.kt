package com.moonlight.launcher.modules.active

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.edit
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.sqrt

data class Waypoint(
    val id: String,
    val name: String,
    val x: Double,
    val y: Double,
    val z: Double,
    val dimension: String = "overworld"
) {
    fun distanceTo(other: Waypoint): Double {
        val dx = x - other.x
        val dy = y - other.y
        val dz = z - other.z
        return sqrt(dx * dx + dy * dy + dz * dz)
    }

    fun distanceXZ(other: Waypoint): Double {
        val dx = x - other.x
        val dz = z - other.z
        return sqrt(dx * dx + dz * dz)
    }

    fun toJson() = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("x", x)
        put("y", y)
        put("z", z)
        put("dimension", dimension)
    }

    companion object {
        fun fromJson(obj: JSONObject) = Waypoint(
            id = obj.optString("id", System.currentTimeMillis().toString()),
            name = obj.optString("name", "Waypoint"),
            x = obj.optDouble("x", 0.0),
            y = obj.optDouble("y", 64.0),
            z = obj.optDouble("z", 0.0),
            dimension = obj.optString("dimension", "overworld")
        )
    }
}

object WaypointsModule {
    private const val PREFS_KEY = "moonlight_waypoints"
    private const val DATA_KEY = "waypoints_json"

    fun load(context: Context): List<Waypoint> {
        val prefs = prefs(context)
        val json = prefs.getString(DATA_KEY, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(json)
            (0 until array.length()).map { Waypoint.fromJson(array.getJSONObject(it)) }
        }.getOrDefault(emptyList())
    }

    fun save(context: Context, waypoints: List<Waypoint>) {
        val array = JSONArray()
        waypoints.forEach { array.put(it.toJson()) }
        prefs(context).edit { putString(DATA_KEY, array.toString()) }
    }

    fun add(context: Context, waypoint: Waypoint) {
        val current = load(context).toMutableList()
        current.add(0, waypoint)
        save(context, current)
    }

    fun remove(context: Context, id: String) {
        val current = load(context).filter { it.id != id }
        save(context, current)
    }

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_KEY, Context.MODE_PRIVATE)
}

@Composable
fun WaypointsScreen(context: Context) {
    val Night = Color(0xFF100D19)
    val SurfaceMoon = Color(0xFF1B1628)
    val SurfaceRaised = Color(0xFF29213A)
    val MoonPurple = Color(0xFFB99AFF)
    val SoftText = Color(0xFFB9B1C8)

    var waypoints by remember { mutableStateOf(WaypointsModule.load(context)) }
    var showAdd by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var xStr by remember { mutableStateOf("") }
    var yStr by remember { mutableStateOf("64") }
    var zStr by remember { mutableStateOf("") }
    var dimension by remember { mutableStateOf("overworld") }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Button(
            onClick = { showAdd = !showAdd },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MoonPurple, contentColor = Night)
        ) {
            Icon(Icons.Default.Add, null)
            Spacer(Modifier.width(6.dp))
            Text("Add Waypoint", fontWeight = FontWeight.Bold)
        }

        if (showAdd) {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                    .background(SurfaceRaised).padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(value = name, onValueChange = { name = it },
                    label = { Text("Name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = xStr, onValueChange = { xStr = it }, label = { Text("X") },
                        modifier = Modifier.weight(1f), singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(value = yStr, onValueChange = { yStr = it }, label = { Text("Y") },
                        modifier = Modifier.weight(1f), singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedTextField(value = zStr, onValueChange = { zStr = it }, label = { Text("Z") },
                        modifier = Modifier.weight(1f), singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                }
                val dims = listOf("overworld", "nether", "end")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    dims.forEach { dim ->
                        FilterChip(selected = dimension == dim, onClick = { dimension = dim },
                            label = { Text(dim.replaceFirstChar { it.uppercase() }, fontSize = 11.sp) })
                    }
                }
                Button(
                    onClick = {
                        val x = xStr.toDoubleOrNull() ?: 0.0
                        val y = yStr.toDoubleOrNull() ?: 64.0
                        val z = zStr.toDoubleOrNull() ?: 0.0
                        val wp = Waypoint(System.currentTimeMillis().toString(), name.ifBlank { "Waypoint" }, x, y, z, dimension)
                        WaypointsModule.add(context, wp)
                        waypoints = WaypointsModule.load(context)
                        showAdd = false; name = ""; xStr = ""; yStr = "64"; zStr = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MoonPurple, contentColor = Night),
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp)
                ) { Text("Save") }
            }
            Spacer(Modifier.height(8.dp))
        }

        if (waypoints.isEmpty()) {
            Column(Modifier.fillMaxWidth().padding(top = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Place, null, tint = SoftText, modifier = Modifier.size(40.dp))
                Spacer(Modifier.height(10.dp))
                Text("No waypoints saved", fontWeight = FontWeight.SemiBold)
                Text("Add coordinates you want to return to.", color = SoftText, fontSize = 12.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(waypoints, key = { it.id }) { wp ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                            .background(SurfaceMoon).padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Place, null, tint = MoonPurple)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(wp.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text("${wp.x.toInt()}, ${wp.y.toInt()}, ${wp.z.toInt()}  •  ${wp.dimension}", color = SoftText, fontSize = 11.sp)
                        }
                        IconButton(onClick = {
                            WaypointsModule.remove(context, wp.id)
                            waypoints = WaypointsModule.load(context)
                        }) {
                            Icon(Icons.Default.Delete, null, tint = SoftText)
                        }
                    }
                }
            }
        }
    }
}
