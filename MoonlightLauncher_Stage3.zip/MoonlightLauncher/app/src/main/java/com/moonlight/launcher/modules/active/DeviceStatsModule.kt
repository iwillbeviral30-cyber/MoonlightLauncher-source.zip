package com.moonlight.launcher.modules.active

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs

/** Reads Android device metrics that are legitimately available to any app. */
object DeviceStatsModule {

    data class DeviceStats(
        val batteryPercent: Int,
        val isCharging: Boolean,
        val storageUsedMb: Long,
        val storageTotalMb: Long,
        val networkType: String,
        val appStorageUsedKb: Long
    )

    fun read(context: Context): DeviceStats {
        // Battery
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val batteryPercent = if (level >= 0) level * 100 / scale else -1
        val chargingStatus = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = chargingStatus == BatteryManager.BATTERY_STATUS_CHARGING ||
                chargingStatus == BatteryManager.BATTERY_STATUS_FULL

        // Storage
        val stat = StatFs(Environment.getDataDirectory().path)
        val storageTotalMb = stat.totalBytes / (1024 * 1024)
        val storageUsedMb = (stat.totalBytes - stat.availableBytes) / (1024 * 1024)

        // App storage
        val appFilesDir = context.filesDir
        val appStorageKb = appFilesDir.walkTopDown().sumOf { if (it.isFile) it.length() else 0L } / 1024L

        // Network
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkType = if (Build.VERSION.SDK_INT >= 23) {
            val net = connectivityManager.activeNetwork
            val caps = connectivityManager.getNetworkCapabilities(net)
            when {
                caps == null -> "Offline"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                else -> "Connected"
            }
        } else "Unknown"

        return DeviceStats(
            batteryPercent = batteryPercent,
            isCharging = isCharging,
            storageUsedMb = storageUsedMb,
            storageTotalMb = storageTotalMb,
            networkType = networkType,
            appStorageUsedKb = appStorageKb
        )
    }
}
