package com.moonlight.launcher.client

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit

/**
 * Single source of truth for all 60 client modules.
 * Modules are honest about what they can do today vs what requires the game runtime.
 */
object ClientRegistry {

    val all: List<ClientModule> = listOf(

        // ── HUD & INFORMATION ─────────────────────────────────────────────
        ClientModule("fps_counter",     "FPS Counter",        "Shows Minecraft's current frames per second.",
            ClientCategory.HUD_INFO, ModuleTier.REQUIRES_RUNTIME, hasSettings = true),
        ClientModule("cps_counter",     "CPS Counter",        "Counts screen taps per second inside the overlay.",
            ClientCategory.HUD_INFO, ModuleTier.OVERLAY_ACTIVE, hasLiveEffect = true, hasSettings = true),
        ClientModule("ping_display",    "Ping Display",       "Shows your server latency. Requires game integration.",
            ClientCategory.HUD_INFO, ModuleTier.REQUIRES_RUNTIME),
        ClientModule("coordinates_hud", "Coordinates HUD",    "Shows X/Y/Z from a Bedrock behavior pack.",
            ClientCategory.HUD_INFO, ModuleTier.REQUIRES_ADDON, hasSettings = true),
        ClientModule("keystrokes",      "Keystrokes",         "Displays physical keyboard key activity.",
            ClientCategory.HUD_INFO, ModuleTier.OVERLAY_ACTIVE, hasLiveEffect = true),
        ClientModule("armor_hud",       "Armor HUD",          "Shows current armor durability. Needs behavior pack.",
            ClientCategory.HUD_INFO, ModuleTier.REQUIRES_ADDON),
        ClientModule("potion_hud",      "Potion HUD",         "Displays active potion effects. Needs behavior pack.",
            ClientCategory.HUD_INFO, ModuleTier.REQUIRES_ADDON),
        ClientModule("direction_hud",   "Direction HUD",      "Compass rose showing facing direction. Needs pack.",
            ClientCategory.HUD_INFO, ModuleTier.REQUIRES_ADDON),
        ClientModule("clock",           "Clock",              "Shows real-world time in the overlay.",
            ClientCategory.HUD_INFO, ModuleTier.OVERLAY_ACTIVE, hasLiveEffect = true),
        ClientModule("item_counter",    "Item Counter",       "Track item counts. Needs behavior pack.",
            ClientCategory.HUD_INFO, ModuleTier.REQUIRES_ADDON),
        ClientModule("arrow_counter",   "Arrow Counter",      "Shows arrows in inventory. Needs behavior pack.",
            ClientCategory.HUD_INFO, ModuleTier.REQUIRES_ADDON),
        ClientModule("totem_counter",   "Totem Counter",      "Shows totems in inventory. Needs behavior pack.",
            ClientCategory.HUD_INFO, ModuleTier.REQUIRES_ADDON),
        ClientModule("speed_display",   "Speed Display",      "Player movement speed. Needs behavior pack.",
            ClientCategory.HUD_INFO, ModuleTier.REQUIRES_ADDON),
        ClientModule("biome_display",   "Biome Display",      "Current biome name. Needs behavior pack.",
            ClientCategory.HUD_INFO, ModuleTier.REQUIRES_ADDON),
        ClientModule("session_timer",   "Session Timer",      "Tracks how long you've been playing this session.",
            ClientCategory.HUD_INFO, ModuleTier.OVERLAY_ACTIVE, hasLiveEffect = true),

        // ── VISUAL MODS ───────────────────────────────────────────────────
        ClientModule("fullbright",       "Fullbright",         "Maximum brightness. Needs resource pack patch.",
            ClientCategory.VISUAL, ModuleTier.REQUIRES_ADDON),
        ClientModule("zoom",             "Zoom",               "Telescope zoom. Needs compatible resource pack.",
            ClientCategory.VISUAL, ModuleTier.REQUIRES_ADDON, hasSettings = true),
        ClientModule("view_model",       "View Model",         "Adjust hand/item position. Needs game runtime.",
            ClientCategory.VISUAL, ModuleTier.REQUIRES_RUNTIME, hasSettings = true),
        ClientModule("freelook",         "Freelook",           "Look around without moving camera. Needs runtime.",
            ClientCategory.VISUAL, ModuleTier.REQUIRES_RUNTIME),
        ClientModule("motion_blur",      "Motion Blur",        "Adds motion blur. Needs shader pack (RenderDragon).",
            ClientCategory.VISUAL, ModuleTier.REQUIRES_ADDON),
        ClientModule("low_fire",         "Low Fire",           "Lowers the fire overlay. Needs resource pack.",
            ClientCategory.VISUAL, ModuleTier.REQUIRES_ADDON),
        ClientModule("low_shield",       "Low Shield",         "Lowers the shield model. Needs resource pack.",
            ClientCategory.VISUAL, ModuleTier.REQUIRES_ADDON),
        ClientModule("hurt_camera",      "Hurt Camera",        "Removes screen-shake on damage. Needs runtime.",
            ClientCategory.VISUAL, ModuleTier.REQUIRES_RUNTIME),
        ClientModule("crosshair",        "Crosshair Customizer","Custom crosshair overlay drawn by Moonlight.",
            ClientCategory.VISUAL, ModuleTier.OVERLAY_ACTIVE, hasLiveEffect = true, hasSettings = true),
        ClientModule("block_overlay",    "Block Overlay",      "Highlights block under crosshair. Needs runtime.",
            ClientCategory.VISUAL, ModuleTier.REQUIRES_RUNTIME),
        ClientModule("hitbox_display",   "Hitbox Display",     "Entity bounding boxes. Needs behavior pack.",
            ClientCategory.VISUAL, ModuleTier.REQUIRES_ADDON),
        ClientModule("environment",      "Environment Changer","Sky/fog color pack. Needs resource pack.",
            ClientCategory.VISUAL, ModuleTier.REQUIRES_ADDON, hasSettings = true),

        // ── PVP ───────────────────────────────────────────────────────────
        ClientModule("combo_counter",    "Combo Counter",      "Hit combo tracking. Needs behavior pack.",
            ClientCategory.PVP, ModuleTier.REQUIRES_ADDON),
        ClientModule("low_health_warn",  "Low Health Warning", "Flash overlay when health is low. Needs pack.",
            ClientCategory.PVP, ModuleTier.REQUIRES_ADDON),
        ClientModule("bow_indicator",    "Bow Indicator",      "Bow charge progress. Needs behavior pack.",
            ClientCategory.PVP, ModuleTier.REQUIRES_ADDON),
        ClientModule("break_indicator",  "Break Indicator",    "Block break progress. Needs behavior pack.",
            ClientCategory.PVP, ModuleTier.REQUIRES_ADDON),
        ClientModule("hit_sound",        "Hit Sound",          "Custom sound on hit. Needs behavior pack.",
            ClientCategory.PVP, ModuleTier.REQUIRES_ADDON),
        ClientModule("tnt_timer",        "TNT Timer",          "TNT fuse countdown. Needs behavior pack.",
            ClientCategory.PVP, ModuleTier.REQUIRES_ADDON),
        ClientModule("projectile_ind",   "Projectile Indicator","Incoming projectile warning. Needs pack.",
            ClientCategory.PVP, ModuleTier.REQUIRES_ADDON),
        ClientModule("entity_counter",   "Nearby Entity Counter","Nearby mob count. Needs behavior pack.",
            ClientCategory.PVP, ModuleTier.REQUIRES_ADDON),

        // ── INVENTORY & GAMEPLAY ──────────────────────────────────────────
        ClientModule("shulker_preview",  "Shulker Preview",    "Preview shulker box contents. Needs pack.",
            ClientCategory.INVENTORY, ModuleTier.REQUIRES_ADDON),
        ClientModule("item_info",        "Item Info",          "Detailed item tooltips. Needs behavior pack.",
            ClientCategory.INVENTORY, ModuleTier.REQUIRES_ADDON),
        ClientModule("auto_tool",        "Auto Tool Switch",   "Best tool for block. Needs game runtime.",
            ClientCategory.INVENTORY, ModuleTier.REQUIRES_RUNTIME),
        ClientModule("auto_replenish",   "Auto Replenish",     "Refill hotbar slots. Needs game runtime.",
            ClientCategory.INVENTORY, ModuleTier.REQUIRES_RUNTIME),
        ClientModule("drop_prevention",  "Drop Prevention",    "Prevent dropping items. Needs runtime.",
            ClientCategory.INVENTORY, ModuleTier.REQUIRES_RUNTIME),
        ClientModule("quick_drop",       "Quick Drop",         "Fast item drop button. Needs runtime.",
            ClientCategory.INVENTORY, ModuleTier.REQUIRES_RUNTIME),
        ClientModule("fast_inventory",   "Fast Inventory",     "Instant inventory open. Needs runtime.",
            ClientCategory.INVENTORY, ModuleTier.REQUIRES_RUNTIME),
        ClientModule("inventory_hud",    "Inventory HUD",      "Hotbar items in overlay. Needs behavior pack.",
            ClientCategory.INVENTORY, ModuleTier.REQUIRES_ADDON),
        ClientModule("hotbar_shortcuts", "Hotbar Shortcuts",   "On-screen hotbar buttons in overlay.",
            ClientCategory.INVENTORY, ModuleTier.OVERLAY_ACTIVE, hasLiveEffect = true, hasSettings = true),
        ClientModule("quick_perspective","Quick Perspective",  "Perspective switcher button overlay.",
            ClientCategory.INVENTORY, ModuleTier.OVERLAY_ACTIVE, hasLiveEffect = true),

        // ── PERFORMANCE & NAVIGATION ──────────────────────────────────────
        ClientModule("fps_unlocker",     "FPS Unlocker",       "Remove frame cap. Needs game runtime.",
            ClientCategory.PERFORMANCE, ModuleTier.REQUIRES_RUNTIME),
        ClientModule("performance_mode", "Performance Mode",   "Low-power device mode. Needs runtime.",
            ClientCategory.PERFORMANCE, ModuleTier.REQUIRES_RUNTIME),
        ClientModule("particle_reducer", "Particle Reducer",   "Reduce particle count. Needs runtime.",
            ClientCategory.PERFORMANCE, ModuleTier.REQUIRES_RUNTIME),
        ClientModule("anim_optimizer",   "Animation Optimizer","Simplify animations. Needs runtime.",
            ClientCategory.PERFORMANCE, ModuleTier.REQUIRES_RUNTIME),
        ClientModule("shader_loader",    "Shader Loader",      "Manage shader packs (.mcpack). Works now.",
            ClientCategory.PERFORMANCE, ModuleTier.APP_ACTIVE, hasLiveEffect = true),
        ClientModule("minimap",          "Minimap",            "World minimap. Needs behavior pack data bridge.",
            ClientCategory.PERFORMANCE, ModuleTier.REQUIRES_ADDON),
        ClientModule("waypoints",        "Waypoints",          "Save and label coordinates. Works now.",
            ClientCategory.PERFORMANCE, ModuleTier.APP_ACTIVE, hasLiveEffect = true, hasSettings = true),
        ClientModule("distance_measure", "Distance Measurer",  "Measure distance between saved waypoints.",
            ClientCategory.PERFORMANCE, ModuleTier.APP_ACTIVE, hasLiveEffect = true),

        // ── LAUNCHER CUSTOMIZATION ────────────────────────────────────────
        ClientModule("hud_editor",       "HUD Editor",         "Drag-and-drop overlay widget editor.",
            ClientCategory.CUSTOMIZATION, ModuleTier.APP_ACTIVE, hasLiveEffect = true),
        ClientModule("theme_editor",     "Theme Editor",       "Change Moonlight colors and accent.",
            ClientCategory.CUSTOMIZATION, ModuleTier.APP_ACTIVE, hasLiveEffect = true, hasSettings = true),
        ClientModule("font_customizer",  "Font Customizer",    "Overlay font size and weight.",
            ClientCategory.CUSTOMIZATION, ModuleTier.APP_ACTIVE, hasSettings = true),
        ClientModule("module_list",      "Module List",        "Floating module list overlay widget.",
            ClientCategory.CUSTOMIZATION, ModuleTier.OVERLAY_ACTIVE, hasLiveEffect = true),
        ClientModule("profiles",         "Profiles",           "Save and load module configuration sets.",
            ClientCategory.CUSTOMIZATION, ModuleTier.APP_ACTIVE, hasLiveEffect = true, hasSettings = true),
        ClientModule("quick_settings",   "Quick Settings",     "Fast-access settings panel in overlay.",
            ClientCategory.CUSTOMIZATION, ModuleTier.OVERLAY_ACTIVE, hasLiveEffect = true),
        ClientModule("overlay_custom",   "Overlay Customizer", "Position and resize overlay elements.",
            ClientCategory.CUSTOMIZATION, ModuleTier.APP_ACTIVE, hasLiveEffect = true)
    )

    // ── Persistence ──────────────────────────────────────────────────────

    private const val PREFS = "moonlight_client_modules"

    fun isEnabled(context: Context, moduleId: String): Boolean =
        prefs(context).getBoolean(moduleId, false)

    fun setEnabled(context: Context, moduleId: String, enabled: Boolean) =
        prefs(context).edit { putBoolean(moduleId, enabled) }

    fun enabledCount(context: Context): Int =
        all.count { isEnabled(context, it.id) }

    fun forCategory(category: ClientCategory): List<ClientModule> =
        all.filter { it.category == category }

    fun search(query: String): List<ClientModule> {
        if (query.isBlank()) return all
        val q = query.trim().lowercase()
        return all.filter { it.name.lowercase().contains(q) || it.description.lowercase().contains(q) }
    }

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
