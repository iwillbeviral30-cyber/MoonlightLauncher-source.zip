package com.moonlight.launcher.pack

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile

data class StoredPack(
    val id: String,
    val displayName: String,
    val path: String,
    val importedAt: Long,
    val inspection: PackInspector.InspectionResult?
) {
    val primaryManifest get() = inspection?.manifests?.firstOrNull()
    val packType get() = primaryManifest?.type ?: PackType.UNKNOWN
    val typeLabel get() = when (packType) {
        PackType.RESOURCE -> "Resource Pack"
        PackType.BEHAVIOR -> "Behavior Pack"
        PackType.SKIN -> "Skin Pack"
        PackType.WORLD_TEMPLATE -> "World Template"
        PackType.UNKNOWN -> "Pack Bundle"
    }
}

object PackRepository {
    private const val MAX_FILE_BYTES = 150L * 1024 * 1024
    private const val MAX_UNCOMPRESSED_BYTES = 512L * 1024 * 1024
    private const val MAX_ENTRIES = 10_000

    private fun importDir(context: Context) = File(context.filesDir, "imports").apply { mkdirs() }
    private fun metaDir(context: Context) = File(context.filesDir, "pack_meta").apply { mkdirs() }

    suspend fun listAll(context: Context): List<StoredPack> = withContext(Dispatchers.IO) {
        val dir = importDir(context)
        val files = dir.listFiles()?.filter { it.isFile && !it.name.endsWith(".meta") } ?: emptyList()
        files.sortedByDescending { it.lastModified() }.map { file ->
            val id = file.name.substringBefore('_')
            val name = file.name.substringAfter('_', file.name)
            val inspection = runCatching { PackInspector.inspect(file) }.getOrNull()
            StoredPack(id, name, file.absolutePath, file.lastModified(), inspection)
        }
    }

    suspend fun importPack(context: Context, uri: Uri): StoredPack = withContext(Dispatchers.IO) {
        val displayName = resolveDisplayName(context, uri)
        val extension = displayName.substringAfterLast('.', "").lowercase()
        require(extension in listOf("mcpack", "mcaddon", "zip")) {
            "Choose a .mcpack, .mcaddon, or .zip file."
        }

        val dir = importDir(context)
        val safeName = displayName.replace(Regex("[^A-Za-z0-9._-]"), "_").take(100)
        val id = System.currentTimeMillis().toString()
        val destination = File(dir, "${id}_$safeName")

        try {
            context.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Android could not open the selected file." }
                FileOutputStream(destination).use { output ->
                    val buffer = ByteArray(8192)
                    var total = 0L
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        total += count
                        require(total <= MAX_FILE_BYTES) { "Pack exceeds the 150 MB import limit." }
                        output.write(buffer, 0, count)
                    }
                }
            }
            safetyCheck(destination)
            val inspection = runCatching { PackInspector.inspect(destination) }.getOrNull()
            StoredPack(id, safeName, destination.absolutePath, System.currentTimeMillis(), inspection)
        } catch (e: Exception) {
            destination.delete()
            throw e
        }
    }

    fun deletePack(context: Context, pack: StoredPack) {
        File(pack.path).delete()
        File(metaDir(context), "${pack.id}.meta").delete()
    }

    private fun resolveDisplayName(context: Context, uri: Uri): String {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) return cursor.getString(index)
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "pack.mcpack"
    }

    private fun safetyCheck(file: File) {
        var totalUncompressed = 0L
        var entries = 0
        var hasManifest = false
        ZipFile(file).use { zip ->
            val it = zip.entries()
            while (it.hasMoreElements()) {
                val entry = it.nextElement()
                entries++
                require(entries <= MAX_ENTRIES) { "Archive has too many entries." }
                val normalized = entry.name.replace('\\', '/')
                require(!normalized.startsWith("/") && normalized.split('/').none { part -> part == ".." }) {
                    "Archive contains an unsafe path: ${entry.name}"
                }
                if (!entry.isDirectory && entry.size > 0) {
                    totalUncompressed += entry.size
                    require(totalUncompressed <= MAX_UNCOMPRESSED_BYTES) { "Archive expands beyond the safety limit." }
                }
                if (!entry.isDirectory && normalized.substringAfterLast('/') == "manifest.json") {
                    val content = zip.getInputStream(entry).bufferedReader().use { r -> r.readText() }
                    val manifest = runCatching { JSONObject(content) }.getOrNull()
                    val header = manifest?.optJSONObject("header")
                    if (header != null && header.has("uuid")) hasManifest = true
                }
            }
        }
        require(hasManifest) { "No valid Bedrock manifest.json found. This may not be a Bedrock add-on." }
    }
}
