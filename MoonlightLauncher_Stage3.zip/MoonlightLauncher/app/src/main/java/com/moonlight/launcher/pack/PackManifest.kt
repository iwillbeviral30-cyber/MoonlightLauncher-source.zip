package com.moonlight.launcher.pack

import org.json.JSONObject

enum class PackType { RESOURCE, BEHAVIOR, SKIN, WORLD_TEMPLATE, UNKNOWN }

data class PackDependency(
    val uuid: String,
    val version: String
)

data class PackCapability(val name: String)

data class PackManifest(
    val name: String,
    val description: String,
    val uuid: String,
    val version: String,
    val minEngineVersion: String?,
    val type: PackType,
    val dependencies: List<PackDependency>,
    val capabilities: List<PackCapability>,
    val hasScripts: Boolean,
    val hasShaders: Boolean,
    val raw: String
) {
    val isResourcePack get() = type == PackType.RESOURCE
    val isBehaviorPack get() = type == PackType.BEHAVIOR
    val requiresExperiments get() = capabilities.isNotEmpty()

    companion object {
        fun parse(json: String): PackManifest? {
            val obj = runCatching { JSONObject(json) }.getOrNull() ?: return null
            val header = obj.optJSONObject("header") ?: return null

            val name = header.optString("name", "Unknown Pack")
            val description = header.optString("description", "")
            val uuid = header.optString("uuid", "")
            val versionArray = header.optJSONArray("version")
            val version = if (versionArray != null) {
                "${versionArray.optInt(0)}.${versionArray.optInt(1)}.${versionArray.optInt(2)}"
            } else {
                header.optString("version", "0.0.0")
            }
            val minEngineArray = header.optJSONArray("min_engine_version")
            val minEngine = if (minEngineArray != null) {
                "${minEngineArray.optInt(0)}.${minEngineArray.optInt(1)}.${minEngineArray.optInt(2)}"
            } else null

            val modulesArray = obj.optJSONArray("modules")
            val type = if (modulesArray != null && modulesArray.length() > 0) {
                val moduleType = modulesArray.getJSONObject(0).optString("type", "")
                when (moduleType.lowercase()) {
                    "resources" -> PackType.RESOURCE
                    "data", "server_ui", "script" -> PackType.BEHAVIOR
                    "skin_pack" -> PackType.SKIN
                    "world_template" -> PackType.WORLD_TEMPLATE
                    else -> PackType.UNKNOWN
                }
            } else PackType.UNKNOWN

            val depsArray = obj.optJSONArray("dependencies")
            val dependencies = mutableListOf<PackDependency>()
            if (depsArray != null) {
                for (i in 0 until depsArray.length()) {
                    val dep = depsArray.getJSONObject(i)
                    val depUuid = dep.optString("uuid", "")
                    val depVerArray = dep.optJSONArray("version")
                    val depVersion = if (depVerArray != null) {
                        "${depVerArray.optInt(0)}.${depVerArray.optInt(1)}.${depVerArray.optInt(2)}"
                    } else dep.optString("version", "0.0.0")
                    if (depUuid.isNotBlank()) dependencies += PackDependency(depUuid, depVersion)
                }
            }

            val capsArray = obj.optJSONArray("capabilities")
            val capabilities = mutableListOf<PackCapability>()
            if (capsArray != null) {
                for (i in 0 until capsArray.length()) {
                    capabilities += PackCapability(capsArray.getString(i))
                }
            }

            // Detect script modules
            val hasScripts = if (modulesArray != null) {
                (0 until modulesArray.length()).any {
                    modulesArray.getJSONObject(it).optString("type", "").lowercase() == "script"
                }
            } else false

            return PackManifest(
                name = name,
                description = description,
                uuid = uuid,
                version = version,
                minEngineVersion = minEngine,
                type = type,
                dependencies = dependencies,
                capabilities = capabilities,
                hasScripts = hasScripts,
                hasShaders = false, // detected from file tree separately
                raw = json
            )
        }
    }
}
