package com.moonlight.launcher.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import com.moonlight.launcher.client.ClientPanel
import com.moonlight.launcher.client.ClientRegistry
import kotlin.math.roundToInt

/**
 * Foreground service that draws a floating Moonlight bubble over other apps.
 *
 * Collapsed state: small draggable ◐ bubble showing active module count + clock.
 * Tap → expands to the full Kuro-style ClientPanel covering 82% of the screen,
 *         with left sidebar, all 60 modules, search, and real toggles.
 *
 * Live working features while overlay is active:
 *  - Real-time clock (updated every second)
 *  - Session timer (elapsed since overlay started)
 *  - CPS counter (taps counted on the bubble itself)
 *  - Enabled module count shown in the bubble
 */
class OverlayService : Service() {

    private lateinit var windowManager: WindowManager

    // State visible to Compose
    private val panelOpen   = mutableStateOf(false)
    private val sessionSecs = mutableLongStateOf(0L)
    private val clockText   = mutableStateOf("00:00")
    private val cpsCount    = mutableIntStateOf(0)
    private val tapTimes    = ArrayDeque<Long>()

    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val ticker  = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            sessionSecs.longValue = (now - sessionStartMs) / 1000L
            clockText.value = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
                .format(java.util.Date(now))
            // Clean tap times older than 1 s for CPS
            val cutoff = now - 1000L
            while (tapTimes.isNotEmpty() && tapTimes.first() < cutoff) tapTimes.removeFirst()
            cpsCount.intValue = tapTimes.size
            handler.postDelayed(this, 500)
        }
    }
    private val sessionStartMs = System.currentTimeMillis()

    // WindowManager params — shared so we can mutate x/y on drag
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var panelParams:  WindowManager.LayoutParams
    private var bubbleView: android.view.View? = null
    private var panelView:  android.view.View? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(NOTIF_ID, buildNotification())
        handler.post(ticker)
        showBubble()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(ticker)
        removeBubble()
        removePanel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ── Bubble (collapsed) ────────────────────────────────────────────────────

    private fun showBubble() {
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        bubbleParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 16; y = 220
        }

        val view = androidx.compose.ui.platform.ComposeView(this).apply {
            setViewTreeLifecycleOwner(OverlayLifecycleOwner())
            setViewTreeSavedStateRegistryOwner(OverlaySavedStateOwner())
            setContent {
                MoonBubble(
                    sessionSecs   = sessionSecs.longValue,
                    clockText     = clockText.value,
                    cps           = cpsCount.intValue,
                    enabledCount  = ClientRegistry.enabledCount(this@OverlayService),
                    onTap         = {
                        tapTimes.addLast(System.currentTimeMillis())
                        openPanel()
                    },
                    onDrag        = { dx, dy ->
                        bubbleParams.x = (bubbleParams.x + dx).roundToInt().coerceAtLeast(0)
                        bubbleParams.y = (bubbleParams.y + dy).roundToInt().coerceAtLeast(0)
                        runCatching { windowManager.updateViewLayout(bubbleView, bubbleParams) }
                    }
                )
            }
        }
        bubbleView = view
        windowManager.addView(view, bubbleParams)
    }

    private fun removeBubble() {
        bubbleView?.let { runCatching { windowManager.removeView(it) } }
        bubbleView = null
    }

    // ── Panel (expanded) ──────────────────────────────────────────────────────

    private fun openPanel() {
        if (panelView != null) return  // already open

        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        // Panel needs to be MATCH_PARENT and focusable so touches work inside it
        panelParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        val view = androidx.compose.ui.platform.ComposeView(this).apply {
            setViewTreeLifecycleOwner(OverlayLifecycleOwner())
            setViewTreeSavedStateRegistryOwner(OverlaySavedStateOwner())
            setContent {
                ClientPanel(
                    context = this@OverlayService,
                    onClose = { closePanel() }
                )
            }
        }
        panelView = view
        windowManager.addView(view, panelParams)
        panelOpen.value = true
    }

    private fun closePanel() {
        removePanel()
        panelOpen.value = false
    }

    private fun removePanel() {
        panelView?.let { runCatching { windowManager.removeView(it) } }
        panelView = null
    }

    // ── Notification ──────────────────────────────────────────────────────────

    private fun buildNotification(): Notification {
        val channelId = "moonlight_overlay"
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(channelId, "Moonlight HUD", NotificationManager.IMPORTANCE_LOW)
            ch.description = "Moonlight client overlay running over Minecraft"
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Moonlight Client")
            .setContentText("Tap the ◐ bubble to open the client panel")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val NOTIF_ID = 1001

        fun start(context: Context) {
            val i = Intent(context, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i)
            else context.startService(i)
        }

        fun stop(context: Context) = context.stopService(Intent(context, OverlayService::class.java))

        fun canDraw(context: Context) =
            if (Build.VERSION.SDK_INT >= 23) android.provider.Settings.canDrawOverlays(context)
            else true
    }
}

// ─── Bubble Composable ────────────────────────────────────────────────────────

@Composable
private fun MoonBubble(
    sessionSecs:  Long,
    clockText:    String,
    cps:          Int,
    enabledCount: Int,
    onTap:        () -> Unit,
    onDrag:       (Float, Float) -> Unit
) {
    val Purple = Color(0xFFB99AFF)
    val Blue   = Color(0xFF8CB8FF)
    val Bg     = Color(0xEE0D0F1A)
    val Soft   = Color(0xFF8A8FA8)

    Box(
        modifier = Modifier
            .size(58.dp)
            .shadow(8.dp, CircleShape)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0xFF1A1D2B), Color(0xFF0D0F1A))
                )
            )
            .pointerInput(Unit) {
                detectDragGestures { change, drag ->
                    change.consume()
                    onDrag(drag.x, drag.y)
                }
            }
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() },
                onClick = onTap
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            // Half-moon glyph
            Text("◐", fontSize = 13.sp, color = Purple, fontWeight = FontWeight.Black)
            Text(clockText, fontSize = 9.sp, color = Blue, fontWeight = FontWeight.SemiBold)
            Text(
                if (enabledCount > 0) "+$enabledCount" else formatSecs(sessionSecs),
                fontSize = 8.sp, color = Soft
            )
        }
    }
}

private fun formatSecs(s: Long): String {
    val m = s / 60; val sec = s % 60
    return "%02d:%02d".format(m, sec)
}
