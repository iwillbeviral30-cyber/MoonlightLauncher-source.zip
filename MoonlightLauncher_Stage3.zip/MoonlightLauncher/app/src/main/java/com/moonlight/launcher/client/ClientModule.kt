package com.moonlight.launcher.client

/**
 * Represents the implementation tier of a client module.
 * Be honest — never mark something OVERLAY_ACTIVE if it only saves a preference.
 */
enum class ModuleTier {
    /** Fully works in the overlay right now (e.g. CPS counter, session timer). */
    OVERLAY_ACTIVE,
    /** Works inside Moonlight app (waypoints, HUD editor, theme). */
    APP_ACTIVE,
    /** Requires a Bedrock behavior/resource pack loaded in Minecraft. */
    REQUIRES_ADDON,
    /** Requires the game to run inside Moonlight's process — not yet available. */
    REQUIRES_RUNTIME,
    /** Feature exists in UI; activates when runtime is available. */
    RUNTIME_READY
}

enum class ClientCategory(val label: String, val icon: String) {
    HUD_INFO("HUD & Info", "📊"),
    VISUAL("Visual Mods", "👁"),
    PVP("PvP", "⚔"),
    INVENTORY("Inventory", "🎒"),
    PERFORMANCE("Performance", "⚡"),
    CUSTOMIZATION("Customization", "🎨")
}

data class ClientModule(
    val id: String,
    val name: String,
    val description: String,
    val category: ClientCategory,
    val tier: ModuleTier,
    /** True if this module currently has an active effect when enabled. */
    val hasLiveEffect: Boolean = false,
    /** If true, shows a chevron → settings panel for this module. */
    val hasSettings: Boolean = false
)

/** Human-readable status label shown on each card. */
val ClientModule.statusLabel: String get() = when (tier) {
    ModuleTier.OVERLAY_ACTIVE  -> "Active"
    ModuleTier.APP_ACTIVE      -> "Active"
    ModuleTier.REQUIRES_ADDON  -> "Needs addon"
    ModuleTier.REQUIRES_RUNTIME-> "Runtime needed"
    ModuleTier.RUNTIME_READY   -> "Runtime ready"
}
