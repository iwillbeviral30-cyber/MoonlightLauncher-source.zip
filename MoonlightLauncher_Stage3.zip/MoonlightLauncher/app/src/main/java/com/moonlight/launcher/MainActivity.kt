package com.moonlight.launcher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import com.moonlight.launcher.minecraft.MinecraftAppResolver
import com.moonlight.launcher.modules.active.DeviceStatsModule
import com.moonlight.launcher.modules.active.SessionTimerModule
import com.moonlight.launcher.modules.active.WaypointsScreen
import com.moonlight.launcher.overlay.OverlayService
import com.moonlight.launcher.pack.PackInspector
import com.moonlight.launcher.pack.PackRepository
import com.moonlight.launcher.pack.PackType
import com.moonlight.launcher.pack.StoredPack

// ── Design tokens ─────────────────────────────────────────────────────────────
private val Night         = Color(0xFF100D19)
private val SurfaceMoon   = Color(0xFF1B1628)
private val SurfaceRaised = Color(0xFF29213A)
private val MoonPurple    = Color(0xFFB99AFF)
private val MoonBlue      = Color(0xFF8CB8FF)
private val SoftText      = Color(0xFFB9B1C8)
private val ColorGreen    = Color(0xFF83D6A7)
private val ColorYellow   = Color(0xFFFFD18A)
private val ColorRed      = Color(0xFFFF9A9A)

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SessionTimerModule.onAppStart(this)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Night, surface = SurfaceMoon,
                    primary = MoonPurple, secondary = MoonBlue,
                    onBackground = Color.White, onSurface = Color.White
                )
            ) { MoonlightApp() }
        }
    }

    override fun onStop()  { super.onStop();  SessionTimerModule.onAppStop(this) }
    override fun onStart() { super.onStart(); SessionTimerModule.onAppStart(this) }
}

// ── 4 tabs — Create removed ───────────────────────────────────────────────────
private enum class Page(val label: String) {
    HOME("Home"), PACKS("Packs"), TOOLS("Tools"), MODULES("Modules")
}

@Composable
private fun MoonlightApp() {
    val context = LocalContext.current
    var page by remember { mutableStateOf(Page.HOME) }
    var packs by remember { mutableStateOf<List<StoredPack>>(emptyList()) }
    var loadingPacks by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        packs = withContext(Dispatchers.IO) { PackRepository.listAll(context) }
        loadingPacks = false
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val result = runCatching { withContext(Dispatchers.IO) { PackRepository.importPack(context, uri) } }
            result.onSuccess { pack ->
                packs = listOf(pack) + packs
                Toast.makeText(context, "Pack imported: ${pack.displayName}", Toast.LENGTH_SHORT).show()
            }.onFailure { e ->
                Toast.makeText(context, e.message ?: "Import failed", Toast.LENGTH_LONG).show()
            }
        }
    }

    Scaffold(
        containerColor = Night,
        bottomBar = {
            NavigationBar(containerColor = SurfaceMoon) {
                Page.entries.forEach { item ->
                    val icon = when (item) {
                        Page.HOME    -> Icons.Default.Home
                        Page.PACKS   -> Icons.Default.FolderOpen
                        Page.TOOLS   -> Icons.Default.Handyman
                        Page.MODULES -> Icons.Default.Tune
                    }
                    NavigationBarItem(
                        selected = page == item,
                        onClick  = { page = item },
                        icon     = { Icon(icon, item.label) },
                        label    = { Text(item.label, fontSize = 10.sp) },
                        colors   = NavigationBarItemDefaults.colors(
                            selectedIconColor   = MoonPurple, selectedTextColor = MoonPurple,
                            indicatorColor      = SurfaceRaised,
                            unselectedIconColor = SoftText,   unselectedTextColor = SoftText
                        )
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (page) {
                Page.HOME -> HomePage(
                    packs = packs,
                    onPlay = {
                        // Launch Minecraft only
                        val ok = runCatching { MinecraftAppResolver.launch(context) }.getOrDefault(false)
                        if (!ok) Toast.makeText(context, "Minecraft Bedrock not found.", Toast.LENGTH_LONG).show()
                    },
                    onPlayWithClient = {
                        // Request overlay permission if needed, then start overlay + Minecraft together
                        if (!OverlayService.canDraw(context)) {
                            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}"))
                            context.startActivity(intent)
                            Toast.makeText(context, "Grant 'Display over other apps' then tap Play + Client again.", Toast.LENGTH_LONG).show()
                        } else {
                            OverlayService.start(context)
                            val ok = runCatching { MinecraftAppResolver.launch(context) }.getOrDefault(false)
                            if (!ok) Toast.makeText(context, "Minecraft not found — overlay is running. You can still open the client bubble.", Toast.LENGTH_LONG).show()
                        }
                    },
                    onGoToPacks = { page = Page.PACKS }
                )
                Page.PACKS -> PacksPage(
                    packs    = packs,
                    loading  = loadingPacks,
                    onImport = { picker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                    onShare  = { pack ->
                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.files", File(pack.path))
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "application/zip"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(intent, "Open with Minecraft"))
                    },
                    onDelete = { pack ->
                        PackRepository.deletePack(context, pack)
                        packs = packs.filter { it.id != pack.id }
                    }
                )
                Page.TOOLS   -> ToolsPage()
                Page.MODULES -> ModulesPage()
            }
        }
    }
}

// ── Brand Header ──────────────────────────────────────────────────────────────

@Composable
private fun BrandHeader(kicker: String) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(MoonPurple))
            Box(Modifier.offset(x = 9.dp, y = (-5).dp).size(30.dp).clip(CircleShape).background(Night))
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text("MOONLIGHT", fontSize = 19.sp, fontWeight = FontWeight.Black, letterSpacing = 1.8.sp)
            Text(kicker.uppercase(), fontSize = 10.sp, color = SoftText, letterSpacing = 1.4.sp)
        }
    }
}

// ── Home Page ─────────────────────────────────────────────────────────────────

@Composable
private fun HomePage(
    packs: List<StoredPack>,
    onPlay: () -> Unit,
    onPlayWithClient: () -> Unit,
    onGoToPacks: () -> Unit
) {
    val context   = LocalContext.current
    val minecraft = remember { MinecraftAppResolver.detect(context) }
    var stats by remember { mutableStateOf<DeviceStatsModule.DeviceStats?>(null) }
    val sessionMs by produceState(0L) {
        while (true) { value = SessionTimerModule.currentSessionMs(); kotlinx.coroutines.delay(1000) }
    }

    LaunchedEffect(Unit) {
        stats = withContext(Dispatchers.IO) { runCatching { DeviceStatsModule.read(context) }.getOrNull() }
    }

    LazyColumn(
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { BrandHeader("Bedrock Client Launcher") }

        // ── Play card ──────────────────────────────────────────────────
        item {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp))
                    .background(SurfaceRaised).padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(8.dp).clip(CircleShape)
                            .background(if (minecraft.installed) ColorGreen else ColorRed)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        if (minecraft.installed) "Minecraft ${minecraft.versionName ?: "Bedrock"} detected"
                        else "Minecraft not installed",
                        fontSize = 12.sp, color = SoftText
                    )
                }
                Spacer(Modifier.height(10.dp))
                Text("Play Minecraft", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Play + Client launches Minecraft and activates the floating ◐ Moonlight client bubble above it.",
                    fontSize = 11.sp, color = SoftText, lineHeight = 15.sp
                )
                Spacer(Modifier.height(16.dp))

                // Play + Client — primary action
                Button(
                    onClick  = onPlayWithClient,
                    enabled  = minecraft.installed,
                    colors   = ButtonDefaults.buttonColors(containerColor = MoonPurple, contentColor = Night),
                    shape    = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("◐", fontSize = 15.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.width(8.dp))
                    Text("Play + Client", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }

                Spacer(Modifier.height(8.dp))

                // Plain Play — secondary
                OutlinedButton(
                    onClick  = onPlay,
                    enabled  = minecraft.installed,
                    shape    = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.PlayArrow, null, tint = MoonPurple)
                    Spacer(Modifier.width(6.dp))
                    Text("Play (no overlay)", color = MoonPurple)
                }
            }
        }

        // ── Stats row ─────────────────────────────────────────────────
        if (stats != null) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile("Battery",
                        if (stats!!.batteryPercent >= 0) "${stats!!.batteryPercent}%" else "—",
                        if (stats!!.batteryPercent <= 15) ColorRed else ColorGreen,
                        Modifier.weight(1f))
                    StatTile("Network", stats!!.networkType, MoonBlue, Modifier.weight(1f))
                    StatTile("Session", SessionTimerModule.formatDuration(sessionMs), MoonPurple, Modifier.weight(1f))
                }
            }
        }

        // ── Quick tiles ───────────────────────────────────────────────
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HomeTile("Your packs", "${packs.size} imported", Icons.Default.FolderOpen, Modifier.weight(1f), onGoToPacks)
                HomeTile("60 modules", "Tap ◐ to access", Icons.Default.Tune, Modifier.weight(1f)) {}
            }
        }

        item {
            InfoCard(
                "How the client works",
                "Tap Play + Client to launch Minecraft with the Moonlight overlay. " +
                "A floating ◐ bubble appears above Minecraft. Tap it to open the full " +
                "client panel with all 60 modules, search, and real toggles."
            )
        }
    }
}

@Composable
private fun StatTile(label: String, value: String, valueColor: Color, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(14.dp)).background(SurfaceMoon).padding(12.dp)) {
        Text(value, fontWeight = FontWeight.Bold, color = valueColor, fontSize = 16.sp)
        Text(label, color = SoftText, fontSize = 10.sp)
    }
}

@Composable
private fun HomeTile(
    title: String, subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier, onClick: () -> Unit
) {
    Column(
        modifier.clip(RoundedCornerShape(18.dp)).background(SurfaceMoon)
            .clickable(onClick = onClick).padding(16.dp)
    ) {
        Icon(icon, null, tint = MoonPurple, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(14.dp))
        Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Text(subtitle, color = SoftText, fontSize = 11.sp)
    }
}

// ── Packs Page ────────────────────────────────────────────────────────────────

@Composable
private fun PacksPage(
    packs: List<StoredPack>,
    loading: Boolean,
    onImport: () -> Unit,
    onShare: (StoredPack) -> Unit,
    onDelete: (StoredPack) -> Unit
) {
    var inspecting by remember { mutableStateOf<StoredPack?>(null) }

    if (inspecting != null) {
        PackInspectSheet(pack = inspecting!!, onDismiss = { inspecting = null }, onShare = { onShare(it) })
        return
    }

    Column(Modifier.fillMaxSize()) {
        BrandHeader("Add-ons & resource packs")
        Button(
            onClick  = onImport,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp),
            shape    = RoundedCornerShape(14.dp),
            colors   = ButtonDefaults.buttonColors(containerColor = MoonPurple, contentColor = Night)
        ) {
            Icon(Icons.Default.FileUpload, null)
            Spacer(Modifier.width(8.dp))
            Text("Import .mcpack / .mcaddon", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(6.dp))
        if (loading) {
            Box(Modifier.fillMaxWidth().padding(top = 60.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = MoonPurple)
            }
        } else if (packs.isEmpty()) {
            Column(Modifier.fillMaxWidth().padding(top = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Inventory2, null, tint = SoftText, modifier = Modifier.size(40.dp))
                Spacer(Modifier.height(12.dp))
                Text("Nothing here yet", fontWeight = FontWeight.SemiBold)
                Text("Import a pack to get started.", color = SoftText, fontSize = 12.sp)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(packs, key = { it.id }) { pack ->
                    PackRow(pack, onInspect = { inspecting = pack }, onShare = { onShare(pack) }, onDelete = { onDelete(pack) })
                }
            }
        }
    }
}

@Composable
private fun PackRow(pack: StoredPack, onInspect: () -> Unit, onShare: () -> Unit, onDelete: () -> Unit) {
    val typeColor = when (pack.packType) {
        PackType.RESOURCE       -> MoonBlue
        PackType.BEHAVIOR       -> ColorYellow
        PackType.SKIN           -> ColorGreen
        PackType.WORLD_TEMPLATE -> MoonPurple
        PackType.UNKNOWN        -> SoftText
    }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(SurfaceMoon)
            .clickable(onClick = onInspect).padding(13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Inventory2, null, tint = typeColor, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(pack.primaryManifest?.name ?: pack.displayName, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(pack.typeLabel + (pack.primaryManifest?.version?.let { " • v$it" } ?: ""), color = SoftText, fontSize = 10.sp)
        }
        TextButton(onClick = onShare) { Text("Open", color = MoonPurple, fontSize = 12.sp) }
        IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, null, tint = SoftText) }
    }
}

@Composable
private fun PackInspectSheet(pack: StoredPack, onDismiss: () -> Unit, onShare: (StoredPack) -> Unit) {
    val inspection = pack.inspection
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onDismiss) { Icon(Icons.Default.ArrowBack, null, tint = MoonPurple) }
            Text("Pack Details", fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
            TextButton(onClick = { onShare(pack) }) { Text("Open / Share", color = MoonPurple) }
        }
        LazyColumn(
            contentPadding    = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (inspection != null) {
                items(inspection.manifests) { manifest ->
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(SurfaceMoon).padding(14.dp)) {
                        Text(manifest.name, fontWeight = FontWeight.Bold)
                        Text(manifest.description, color = SoftText, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        InfoRow("Type", manifest.type.name.replace("_", " "))
                        InfoRow("Version", manifest.version)
                        if (manifest.minEngineVersion != null) InfoRow("Min Engine", manifest.minEngineVersion)
                        InfoRow("UUID", manifest.uuid.take(18) + "…")
                        if (manifest.dependencies.isNotEmpty()) InfoRow("Deps", "${manifest.dependencies.size}")
                        if (manifest.hasScripts) InfoRow("Scripts", "Yes — review before enabling")
                    }
                }
                item {
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(SurfaceMoon).padding(14.dp)) {
                        Text("Archive", fontWeight = FontWeight.SemiBold, color = SoftText, fontSize = 11.sp)
                        Spacer(Modifier.height(6.dp))
                        InfoRow("Files", "${inspection.fileCount}")
                        InfoRow("Uncompressed", "${inspection.uncompressedSizeKb} KB")
                        if (inspection.hasTextures) InfoRow("Textures", "Yes")
                        if (inspection.hasSounds)   InfoRow("Sounds", "Yes")
                        if (inspection.hasModels)   InfoRow("Models", "Yes")
                        if (inspection.hasShaders)  InfoRow("Shaders", "Yes — RenderDragon required")
                    }
                }
                if (inspection.warnings.isNotEmpty()) {
                    item {
                        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(SurfaceRaised).padding(14.dp)) {
                            Text("Notes", color = ColorYellow, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                            Spacer(Modifier.height(6.dp))
                            inspection.warnings.forEach { w ->
                                Row(Modifier.padding(vertical = 2.dp)) {
                                    Text("• ", color = ColorYellow, fontSize = 12.sp)
                                    Text(w, color = SoftText, fontSize = 12.sp, lineHeight = 16.sp)
                                }
                            }
                        }
                    }
                }
            } else {
                item { InfoCard("Inspection unavailable", "The archive could not be inspected. It may still be a valid pack.") }
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = SoftText, fontSize = 11.sp, modifier = Modifier.weight(1f))
        Text(value, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

// ── Tools Page ────────────────────────────────────────────────────────────────

@Composable
private fun ToolsPage() {
    val context = LocalContext.current
    var tool by remember { mutableStateOf("main") }

    when (tool) {
        "waypoints" -> Column {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { tool = "main" }) { Icon(Icons.Default.ArrowBack, null, tint = MoonPurple) }
                Text("Waypoints", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
            WaypointsScreen(context)
        }
        "stats" -> {
            var stats by remember { mutableStateOf<DeviceStatsModule.DeviceStats?>(null) }
            val sessionMs by produceState(0L) {
                while (true) { value = SessionTimerModule.currentSessionMs(); kotlinx.coroutines.delay(1000) }
            }
            LaunchedEffect(Unit) {
                stats = withContext(Dispatchers.IO) { runCatching { DeviceStatsModule.read(context) }.getOrNull() }
            }
            Column {
                Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { tool = "main" }) { Icon(Icons.Default.ArrowBack, null, tint = MoonPurple) }
                    Text("Device Stats", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
                LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(SurfaceMoon).padding(14.dp)) {
                            Text("Session", color = MoonPurple, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                            Spacer(Modifier.height(6.dp))
                            InfoRow("Current", SessionTimerModule.formatDuration(sessionMs))
                            InfoRow("Total", SessionTimerModule.formatDuration(SessionTimerModule.totalMs(context)))
                        }
                    }
                    if (stats != null) {
                        item {
                            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(SurfaceMoon).padding(14.dp)) {
                                Text("Device", color = MoonPurple, fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                                Spacer(Modifier.height(6.dp))
                                if (stats!!.batteryPercent >= 0)
                                    InfoRow("Battery", "${stats!!.batteryPercent}%${if (stats!!.isCharging) " (charging)" else ""}")
                                InfoRow("Network", stats!!.networkType)
                                InfoRow("Storage", "${stats!!.storageUsedMb} MB / ${stats!!.storageTotalMb} MB")
                            }
                        }
                    }
                }
            }
        }
        else -> Column(Modifier.fillMaxSize()) {
            BrandHeader("Tools")
            LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item { ToolTile("Waypoints",    "Save and manage coordinates",   Icons.Default.Place)    { tool = "waypoints" } }
                item { ToolTile("Device Stats", "Battery, storage, session time", Icons.Default.BarChart) { tool = "stats"     } }
            }
        }
    }
}

@Composable
private fun ToolTile(
    title: String, subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(SurfaceMoon)
            .clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = MoonPurple, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = SoftText, fontSize = 12.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = SoftText)
    }
}

// ── Modules Page (catalogue view) ────────────────────────────────────────────

@Composable
private fun ModulesPage() {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var selectedCat by remember { mutableStateOf("All") }

    val cats = listOf("All") + com.moonlight.launcher.client.ClientCategory.entries.map { it.label }
    val allModules = com.moonlight.launcher.client.ClientRegistry.all
    val filtered = allModules.filter { m ->
        (selectedCat == "All" || m.category.label == selectedCat) &&
        (query.isBlank() || m.name.lowercase().contains(query.lowercase()) || m.description.lowercase().contains(query.lowercase()))
    }

    Column(Modifier.fillMaxSize()) {
        BrandHeader("Module Catalogue")
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp),
            label = { Text("Search modules") }, singleLine = true
        )
        Spacer(Modifier.height(6.dp))
        // Category chips
        androidx.compose.foundation.lazy.LazyRow(
            contentPadding = PaddingValues(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(cats) { cat ->
                FilterChip(
                    selected = selectedCat == cat,
                    onClick  = { selectedCat = cat },
                    label    = { Text(cat, fontSize = 10.sp) }
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(filtered, key = { it.id }) { module ->
                val statusColor = when (module.tier) {
                    com.moonlight.launcher.client.ModuleTier.OVERLAY_ACTIVE   -> ColorGreen
                    com.moonlight.launcher.client.ModuleTier.APP_ACTIVE       -> ColorGreen
                    com.moonlight.launcher.client.ModuleTier.REQUIRES_ADDON   -> ColorYellow
                    com.moonlight.launcher.client.ModuleTier.REQUIRES_RUNTIME -> ColorRed
                    com.moonlight.launcher.client.ModuleTier.RUNTIME_READY    -> ColorYellow
                }
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(13.dp))
                        .background(SurfaceMoon).padding(13.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(module.name, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text(module.statusLabel, color = statusColor, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(3.dp))
                    Text(module.description, color = SoftText, fontSize = 11.sp)
                    Text(module.category.label, color = Color(0xFF6D6480), fontSize = 10.sp)
                }
            }
        }
    }
}

// ── Shared UI ─────────────────────────────────────────────────────────────────

@Composable
private fun InfoCard(title: String, body: String) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(SurfaceMoon).padding(15.dp)
    ) {
        Text(title, color = MoonPurple, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Spacer(Modifier.height(5.dp))
        Text(body, color = SoftText, fontSize = 12.sp, lineHeight = 17.sp)
    }
}
