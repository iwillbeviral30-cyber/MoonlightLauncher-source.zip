package com.moonlight.launcher

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile

data class ImportedPack(val name: String, val path: String, val importedAt: Long)

object PackImporter {
    private const val MAX_FILE_BYTES = 150L * 1024L * 1024L
    private const val MAX_UNCOMPRESSED_BYTES = 512L * 1024L * 1024L
    private const val MAX_ENTRIES = 10_000

    fun list(context: Context): List<ImportedPack> {
        val directory = File(context.filesDir, "imports")
        return directory.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() }
            ?.map { ImportedPack(it.name.substringAfter('_', it.name), it.absolutePath, it.lastModified()) }
            ?: emptyList()
    }

    fun displayName(context: Context, uri: Uri): String {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) return cursor.getString(index)
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "import.mcpack"
    }

    fun import(context: Context, uri: Uri, displayName: String): ImportedPack {
        val extension = displayName.substringAfterLast('.', "").lowercase()
        require(extension == "mcpack" || extension == "mcaddon") {
            "Choose a .mcpack or .mcaddon file."
        }

        val directory = File(context.filesDir, "imports").apply { mkdirs() }
        val safeName = displayName.replace(Regex("[^A-Za-z0-9._-]"), "_").take(100)
        val destination = File(directory, "${System.currentTimeMillis()}_$safeName")

        try {
            context.contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "Android could not open the selected file." }
                FileOutputStream(destination).use { output ->
                    val buffer = ByteArray(8192)
                    var total = 0L
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        total += count
                        require(total <= MAX_FILE_BYTES) { "Pack exceeds the 150 MB import limit." }
                        output.write(buffer, 0, count)
                    }
                }
            }
            validateArchive(destination)
            return ImportedPack(safeName, destination.absolutePath, System.currentTimeMillis())
        } catch (error: Exception) {
            destination.delete()
            throw error
        }
    }

    private fun validateArchive(file: File) {
        var totalUncompressed = 0L
        var entries = 0
        var validManifest = false
        ZipFile(file).use { zip ->
            val iterator = zip.entries()
            while (iterator.hasMoreElements()) {
                val entry = iterator.nextElement()
                entries++
                require(entries <= MAX_ENTRIES) { "Archive contains too many entries." }
                val normalized = entry.name.replace('\\', '/')
                require(!normalized.startsWith("/") && normalized.split('/').none { it == ".." }) {
                    "Archive contains an unsafe path."
                }
                if (!entry.isDirectory && entry.size > 0) {
                    totalUncompressed += entry.size
                    require(totalUncompressed <= MAX_UNCOMPRESSED_BYTES) {
                        "Archive expands beyond the 512 MB safety limit."
                    }
                }
                if (!entry.isDirectory && normalized.substringAfterLast('/') == "manifest.json") {
                    val content = zip.getInputStream(entry).bufferedReader().use { it.readText() }
                    val manifest = runCatching { JSONObject(content) }.getOrNull()
                    val header = manifest?.optJSONObject("header")
                    if (header != null && header.has("name") && header.has("uuid") && header.has("version")) {
                        validManifest = true
                    }
                }
            }
        }
        require(validManifest) { "No valid Bedrock pack manifest was found in the archive." }
    }
}
