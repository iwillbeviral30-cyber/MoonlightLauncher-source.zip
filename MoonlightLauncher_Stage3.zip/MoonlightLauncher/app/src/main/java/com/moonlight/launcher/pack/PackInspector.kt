package com.moonlight.launcher.pack

import java.io.File
import java.util.zip.ZipFile

/**
 * Reads an imported archive and extracts all pack manifests plus a file tree summary.
 * Handles both single packs (.mcpack) and multi-pack bundles (.mcaddon).
 */
object PackInspector {

    data class InspectionResult(
        val manifests: List<PackManifest>,
        val fileCount: Int,
        val hasTextures: Boolean,
        val hasSounds: Boolean,
        val hasModels: Boolean,
        val hasAnimations: Boolean,
        val hasScripts: Boolean,
        val hasShaders: Boolean,
        val uncompressedSizeKb: Long,
        val warnings: List<String>
    )

    fun inspect(file: File): InspectionResult {
        val manifests = mutableListOf<PackManifest>()
        val warnings = mutableListOf<String>()
        var fileCount = 0
        var hasTextures = false
        var hasSounds = false
        var hasModels = false
        var hasAnimations = false
        var hasScripts = false
        var hasShaders = false
        var uncompressedBytes = 0L

        runCatching {
            ZipFile(file).use { zip ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    if (entry.isDirectory) continue
                    fileCount++
                    val path = entry.name.replace('\\', '/').lowercase()
                    uncompressedBytes += maxOf(entry.size, 0L)

                    if (path.endsWith("manifest.json")) {
                        val content = zip.getInputStream(entry).bufferedReader().use { it.readText() }
                        val manifest = PackManifest.parse(content)
                        if (manifest != null) manifests += manifest
                        else warnings += "Unreadable manifest at: ${entry.name}"
                    }

                    when {
                        path.contains("/textures/") -> hasTextures = true
                        path.contains("/sounds/") -> hasSounds = true
                        path.contains("/models/") -> hasModels = true
                        path.contains("/animations/") -> hasAnimations = true
                        path.contains("/scripts/") || path.endsWith(".js") -> hasScripts = true
                        path.contains("/shaders/") || path.endsWith(".material") || path.endsWith(".bin") -> hasShaders = true
                    }
                }
            }
        }.onFailure {
            warnings += "Could not fully read archive: ${it.message}"
        }

        if (manifests.isEmpty()) warnings += "No valid pack manifest found."
        if (hasScripts) warnings += "Pack contains scripts. Enable only from creators you trust."
        if (hasShaders) warnings += "Pack contains shader files. RenderDragon shader support varies by device and Minecraft version."

        val depUuids = manifests.flatMap { it.dependencies }.map { it.uuid }.toSet()
        val packUuids = manifests.map { it.uuid }.toSet()
        val missing = depUuids - packUuids
        if (missing.isNotEmpty()) {
            warnings += "Missing ${missing.size} dependency pack(s). Check the creator's bundle."
        }

        return InspectionResult(
            manifests = manifests,
            fileCount = fileCount,
            hasTextures = hasTextures,
            hasSounds = hasSounds,
            hasModels = hasModels,
            hasAnimations = hasAnimations,
            hasScripts = hasScripts,
            hasShaders = hasShaders,
            uncompressedSizeKb = uncompressedBytes / 1024L,
            warnings = warnings
        )
    }
}
