package com.moonlight.launcher.modules

/** A capability record. A module is not toggleable unless it has a real implementation. */
enum class ModuleCategory {
    PERFORMANCE, DISPLAY, PVP, WORLD, HUD, QUALITY_OF_LIFE, SHADERS
}

enum class ModuleStatus {
    WORKING, PARTIAL, EXPERIMENTAL, UNSUPPORTED, PLANNED
}

enum class ModuleExecution {
    ANDROID_APP, BEDROCK_ADDON, DISPLAY_ONLY, EXTERNAL_INTEGRATION, NONE
}

data class ModuleDefinition(
    val id: String,
    val name: String,
    val category: ModuleCategory,
    val description: String,
    val status: ModuleStatus,
    val execution: ModuleExecution,
    val reason: String,
    val requiresOverlayPermission: Boolean = false,
    val enabledByDefault: Boolean = false
)
