# Test checklist

## Existing app
- [ ] Gradle sync succeeds in Android Studio.
- [ ] Debug APK assembles with JDK 17 and Android SDK Platform 36.
- [ ] App launches on Android 8.0+.
- [ ] Import valid `.mcpack` and `.mcaddon` files.
- [ ] Reject wrong extensions, corrupt ZIPs, traversal paths, excessive entries and oversized archives.
- [ ] Imported items remain listed after app restart.
- [ ] Share/open grants Android read access.

## New foundation
- [ ] Module catalogue contains at least 60 unique IDs.
- [ ] Unsupported modules have no execution path.
- [ ] Search finds modules by name/category.
- [ ] Minecraft detection reports installed/not installed correctly on Android 11+.
- [ ] Play launches official Minecraft when installed; handles missing package gracefully.

## Minecraft
- [ ] Confirm Minecraft is offered by Android's app chooser on target device.
- [ ] Import known-good packs created for the exact installed Bedrock version.
- [ ] Enable packs in a disposable test world and inspect behavior.
- [ ] Back up important worlds before testing behavior packs.

No successful APK build or device test is claimed until those checks have actually run.
