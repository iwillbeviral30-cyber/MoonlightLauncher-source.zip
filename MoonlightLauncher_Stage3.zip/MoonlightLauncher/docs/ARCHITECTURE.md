# Architecture

- `MainActivity` owns the Compose UI and Android document-picker flow.
- `PackImporter` copies SAF-selected streams into app-private storage and validates archive structure.
- `minecraft/MinecraftAppResolver` checks visibility of the official Bedrock package and starts its launch intent. It does not inspect or modify game-private data.
- `modules/ModuleCatalog` is a declarative catalogue. UI switches must be enabled only for implemented capabilities; `UNSUPPORTED` and `PLANNED` are informational.
- `FileProvider` grants temporary read access for supported file handoff.

Planned separations: `packs`, `hud`, `overlay`, `compatibility`, and `storage` domain layers. The HUD editor and Android overlay are distinct: editing a layout does not mean Minecraft can render or consume it.
