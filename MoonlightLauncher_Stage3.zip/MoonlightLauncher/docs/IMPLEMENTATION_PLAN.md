# Moonlight implementation plan

## Project audit

The source of truth for this work is the 19-file `MoonlightLauncher-Legit-AndroidStudio.zip` archive. It contains a Jetpack Compose Android app, `.mcpack`/`.mcaddon` importer, private file storage, FileProvider sharing, starter pack manifests, documentation and a GitHub Actions workflow. It does not contain a Gradle wrapper, tests, Minecraft detection, module registry, HUD editor, overlay service, or a verified APK.

## Architecture

- `ui`: Jetpack Compose screens and navigation.
- `minecraft`: installed-app detection and launch intent only; no private game storage access.
- `packs`: SAF import/export, archive validation, manifest parsing, dependency index and backup metadata.
- `modules`: declarative module catalogue, status and capability metadata; unsupported entries are not toggleable.
- `hud`: Moonlight-side layout model/editor; game display requires a separately verified bridge.
- `overlay`: optional Android overlay permission/service, only after lifecycle and target-SDK review.
- `compatibility`: static manifest and dependency checks, never a guarantee of runtime compatibility.
- `storage`: app-private preferences and profile metadata.

## Stages

1. Audit and preserve existing source.
2. Repair reproducible Android build configuration and add tests.
3. Expand launcher UI.
4. Detect and launch installed Bedrock package `com.mojang.minecraftpe`.
5. Expand pack manager to `.mcpack`, `.mcaddon`, `.mcworld` and supported ZIP archives.
6. Register 60–80+ modules with explicit implementation states.
7. Build a menu route using only supported Android/Bedrock integration.
8. Build a grid-snap Moonlight HUD editor and saved layouts.
9. Add device-level performance tools; label game-internal metrics unavailable unless sourced.
10. Add supported PvP statistics and pack-side utilities.
11. Add world and quality-of-life tools exposed by supported APIs.
12. Implement optional floating controls with explicit overlay permission.
13. Add static Bedrock compatibility checks.
14. Run unit, archive, emulator and device tests.
15. Add Gradle wrapper and GitHub Actions tests/build/artifact upload.
16. Package source ZIP and APK only after successful build.

## Compatibility rules

- `WORKING`: implemented in Moonlight and testable without unsupported game access.
- `PARTIAL`: a subset works; limitations are displayed.
- `EXPERIMENTAL`: prototype or pack-side route needs runtime verification.
- `UNSUPPORTED`: no implementation switch; explain why.
- `PLANNED`: not implemented yet.

Bedrock engine version, manifest format and Script API module versions are checked separately. The target version 26.51 is not treated as proof that an arbitrary add-on or Script API dependency is compatible.
