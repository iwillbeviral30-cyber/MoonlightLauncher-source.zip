# Compatibility and limitations

- Android minimum SDK: 26 (Android 8.0).
- Compile/target SDK: 36.
- Java toolchain: 17.
- Import extensions: `.mcpack` and `.mcaddon`.
- Archive validation checks for a JSON `manifest.json` with `header.name`, `header.uuid`, and `header.version`, plus conservative ZIP safety limits.
- Android may not offer Minecraft as a share target on every device or release. If it does not, use Minecraft's own supported import workflow.
- Android scoped storage prevents ordinary apps from silently writing into another app's private directory. Moonlight uses Android's document picker and share intents.
- Bedrock 26.51 is a target profile supplied in the original brief, not a guarantee that every add-on works on it. Pack authors control their own minimum engine version, dependencies, and script API requirements.
- This project does not bundle or claim a particular Minecraft Script API compatibility level.

## Module capability labels

- `WORKING`: implemented in Moonlight itself and independently testable.
- `PARTIAL`: only the stated subset is available.
- `EXPERIMENTAL`: prototype or Bedrock add-on route requires target-device/world verification.
- `UNSUPPORTED`: no toggle is offered because no legitimate API route is currently available.
- `PLANNED`: catalogue entry only; implementation has not started.

The module catalogue is a capability inventory, not a promise that every module is active. A separate Android app cannot infer live Minecraft FPS, frame time, ping, camera state, player position or touch input without an explicit supported game-side data source.
