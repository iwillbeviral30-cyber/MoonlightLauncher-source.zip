# Moonlight Launcher

Moonlight is an Android companion launcher for Minecraft Bedrock. It launches the official installed Minecraft app and manages add-on files through Android-supported document and sharing APIs. It does not recreate the Minecraft engine or access Minecraft's private storage.

## Current implementation baseline

- Jetpack Compose / Material 3 app shell.
- `.mcpack` and `.mcaddon` import with archive safety checks.
- Private local import storage and Android FileProvider handoff.
- Starter Bedrock behavior/resource pack manifests.
- New module catalogue with 60+ entries and explicit capability states.
- Minecraft package detection and launch integration foundation.

## Important limitations

A separate Android app cannot assume access to Minecraft's live FPS, frame time, ping, camera state, target entity, player coordinates or input stream. Those require a supported Bedrock add-on/API route or another documented integration. An Android overlay is external to Minecraft and requires the user's special overlay permission. No memory injection, protected-file access, server bypass or gameplay automation is used.

## Build

Open this folder in Android Studio with JDK 17 and Android SDK Platform 36. The GitHub Actions workflow currently provisions Gradle 8.13 and runs `assembleDebug`; a Gradle wrapper and test/build verification are part of the next build-hardening stage.

See `docs/IMPLEMENTATION_PLAN.md`, `docs/COMPATIBILITY.md`, `docs/ARCHITECTURE.md` and `docs/TESTING.md`.
