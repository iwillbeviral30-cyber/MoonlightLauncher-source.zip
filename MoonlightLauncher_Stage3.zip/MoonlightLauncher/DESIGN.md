# Moonlight design decisions

**Reading this as:** Android Minecraft companion launcher for Bedrock players, in a LeviLauncher-inspired compact gaming utility language with original Moonlight identity.

**Dials:** ENERGY 2 / RHYTHM 2 / MOTION 2.

- ENERGY 2: dark surfaces, a restrained moon-purple accent, and limited visual noise.
- RHYTHM 2: compact utility cards and predictable bottom navigation.
- MOTION 2: native navigation feedback only; no decorative animation dependency.

The reference informs density and utility-first navigation, not copied branding or assets. Moonlight uses its own name, crescent mark, and palette.

## Scope boundary

The first release is a companion utility, not a cheat client. It imports local Bedrock packs, stores them privately, performs basic archive checks, and hands them to Android's app chooser. It does not claim direct installation into Minecraft's private data directory, in-game toggles, rendering overlays, PvP automation, or client injection.
